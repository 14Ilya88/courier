<?php
use App\Services\Page;
?>
<html>
<?php
Page::par('head');
?>
<body>
<?php
Page::par('navbar');
?>
<div class="container-xxl">
    <h3>Главная</h3>
    <hr>
</div>

</body>
</html>